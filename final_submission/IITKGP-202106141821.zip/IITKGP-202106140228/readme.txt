Team : IITKGP

Team Members: 
1) Tejas Vaidhya : iamtejasvaidhya@gmail.com (+91 9340004079)
2) Jalaj Harkawat: jharkawat@gmail.com (+91 9983745427)

About the system(task 1 NER) : 
Our final model use domain-specific Bert (pretrained on the Spanish language) to get the contextualise token 
representation and infused it with features obtained from Bio BERT to transfer knowledge of the medical domain 
in the final representation.